#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from apyori import apriori


# In[3]:


pip install apyori


# In[7]:


df=pd.read_csv("D:/DATA SCIENCE PROJECT/Association rule mining\/store_data.csv", header=None)


# In[8]:


df


# In[9]:


df.head()


# In[10]:


df.tail()


# In[11]:


df.info()


# In[13]:


records=[]
for i in range(len(df)):
    records.append([df.values[i,j] for j in range (20) if df.values[i,j]!="NaN"])
records


# In[20]:


df=[[j for j in i if pd.notna(j)] for i in df.values.tolist()]


# In[23]:


rule=apriori(df, min_support=0.005,min_confidence=0.2, min_lift=3 , max_length=3)
result=list(rule)


# In[24]:


result


# In[28]:


rows = []

for record in result: 
    support = record.support

    for stat in record.ordered_statistics:
        items_base = ", ".join(stat.items_base)
        items_add = ", ".join(stat.items_add)

        rows.append({
            "items_base": items_base,
            "items_add": items_add,
            "support": support,
            "confidence": stat.confidence,
            "lift": stat.lift
        })

df_rules = pd.DataFrame(rows)


df_rules["rule"] = df_rules["items_base"] + " → " + df_rules["items_add"]


df_rules = df_rules.sort_values(by="lift", ascending=False).reset_index(drop=True)

df_rules


# In[ ]:




