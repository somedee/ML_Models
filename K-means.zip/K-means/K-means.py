#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


df=pd.read_excel("D:/DATA SCIENCE PROJECT/K-means/Dataset-Kmeans-xclara.csv.xlsx")


# In[4]:


df


# In[5]:


df.shape


# In[11]:


# scatter plot to check cluster 
sns.scatterplot(x="V1",y="V2", data=df)
plt.xlabel("V1")
plt.ylabel("V2")
plt.show() #there are 3 groups 


# In[13]:


df.head()


# In[14]:


df.tail()


# In[15]:


df.info() # no need to change the data type


# In[16]:


df.describe() # may be outliers we will check


# In[18]:


df.isnull().sum()# no null


# In[19]:


df.isna().sum() # no na 


# In[23]:


df.duplicated().sum() # no duplicates 


# In[25]:


# check outliers
for i in df.columns:
    sns.boxplot(df[i])
    plt.show()  # no outliers data is clean


# In[27]:


# we have clean data , we will directly build model
x=df[["V1","V2"]]

#Feature scaling


from sklearn.preprocessing import StandardScaler
s=StandardScaler()
x=s.fit_transform(x)


# In[43]:


# calculate k value 
from sklearn.cluster import KMeans

k = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, random_state=42)
    kmeans.fit(x)
    k.append(kmeans.inertia_)


# In[44]:


df1=pd.DataFrame({"k":range(1,11),"error":k})


# In[45]:


df1


# In[47]:


sns.lineplot(x="k",y="error", data=df1)
plt.show() # by the graph we acn interpret that k=3 is good elbow


# In[51]:


from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=3, random_state=100)
model = kmeans.fit_predict(x) 


# In[52]:


df["cluster"]=model


# In[53]:


df


# In[55]:


# now we got new cluster will check with scatter plot
sns.scatterplot(x="V1",y="V2",hue="cluster", data=df)
plt.show()


# In[56]:


from sklearn.metrics import silhouette_score

sil_score = silhouette_score(x, df["cluster"])
print("Silhouette Score:", sil_score)

#1.0 → Perfectly separated clusters

#0.5 – 1.0 → Strong, well-separated clusters 

#0 – 0.5 → Moderate overlap

# 0 → Wrong clustering


#Our sil score is between 0.5 -1 menas well sepearted  Silhouette Score: 0.691175770764278


# In[57]:


# Conclusion
#The K-Means model achieved a Silhouette Score of 0.69, indicating strong cluster cohesion and clear separation between clusters. This confirms that the chosen number of clusters (K = 3) effectively captures the underlying structure of the data.


# In[58]:





# In[ ]:




