#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


df=pd.read_excel("D:\DATA SCIENCE PROJECT\Logi reg\glass_df.xlsx")


# In[3]:


df


# In[4]:


#DATA CLEANING
df.head()


# In[5]:


df.tail()


# In[6]:


df.info()


# In[7]:


df.describe()


# In[8]:


df.isnull().sum() # no null present


# In[9]:


df.duplicated().sum()# only one duplicate we can drop that , if multiple we can drop


# In[10]:


df.drop_duplicates(inplace=True) #deleted


# In[11]:


df.duplicated().sum()


# In[12]:


df.isna().sum()


# In[13]:


# EDA segegrate col using dtype 
coln=df.select_dtypes(include="number").columns
cols=df.select_dtypes(exclude="number").columns
coln


# In[14]:


sns.countplot(x="glass_type", data=df) # to check how many variable we have 


# In[15]:


# check outliers with every columns some of the columns overlapping we cant directly drop that feature so will check on emore time with heatmap
for i in coln:
    sns.boxplot(x=df["glass_type"], y=i, data=df)
    plt.title(i)
    plt.show()


# In[16]:


#heatmap
df.corr()
sns.heatmap(df.corr(), annot=True,annot_kws={"size":7})
#'mg', 'al', 'ba', 'na' only this variable has good corr , except this delete all


# In[17]:


df.drop(df[["ri","na","si","k","ca","fe"]], inplace=True, axis=1)


# In[18]:


df["glass_type"].value_counts


# In[19]:


#Delete na with ffil
df["glass_type"]=df["glass_type"].ffill()


# In[20]:


df.isna().sum()


# In[21]:


# Now target varibale has 6 varible will convert into binary
df["glass_type"]=df["glass_type"].map({1:0,2:0,3:0,4:1,5:1,6:1,7:1})


# In[22]:


df["glass_type"].isna().sum()


# In[ ]:





# In[23]:


df.isna().sum()


# In[24]:


for column in df.columns:# al and ba has outliers
    
    sns.boxplot(y=df[column],data=df)
    plt.title(f'Box Plot of {column}')
    plt.show()


# In[25]:


#Now model ready to build

x=df.iloc[::,0:3]
y=df.iloc[::,-1:]




# In[27]:


from sklearn.linear_model import  LogisticRegression
from sklearn.model_selection import train_test_split

x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.2, random_state=42)


# In[ ]:





# In[28]:


# standardization

from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train_scaled=sc.fit_transform(x_train)
x_test_scaled=sc.transform(x_test)


# In[31]:


# Apply lda
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
lda = LinearDiscriminantAnalysis(n_components=1)

x_train_lda = lda.fit_transform(x_train_scaled, y_train)
x_test_lda  = lda.transform(x_test_scaled)


# In[32]:


model=LogisticRegression()
model.fit(x_train_lda, y_train)


# In[34]:


# now validation
pred=model.predict(x_test_lda)


# In[35]:


pred


# In[36]:


from sklearn.metrics import precision_score, recall_score

precision = precision_score(y_test, pred)
recall = recall_score(y_test, pred)

print("Precision:", precision)
print("Recall:", recall)


# In[37]:


from sklearn.metrics import classification_report

print(classification_report(y_test, y_pred))


# In[38]:


#INSIGHTS
For Class 0

Support = 30  There are 30 actual samples of class 0

Precision = 0.90 Out of all predictions made as class 0, 90% were correct

Recall = 0.90 Out of all actual class 0 samples, 90% were correctly identified

F1-score = 0.90 Very good balance between precision and recall

Model performs very well on class 0


# In[274]:


For Class 1

Support = 13  There are 13 actual samples of class 1

Precision = 0.77 Out of all predictions made as class 1, 77% were correct

Recall = 0.77 Out of all actual class 1 samples, 77% were correctly identified

F1-score = 0.77 Moderate performance compared to class 0

Model struggles more with class 1 due to fewer samples


# In[ ]:


Accuracy = 0.86 (86%)

Out of 43 total test samples, 86% were correctly classified

