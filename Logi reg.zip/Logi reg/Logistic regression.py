#!/usr/bin/env python
# coding: utf-8

# In[220]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[244]:


df=pd.read_excel("D:\DATA SCIENCE PROJECT\Logi reg\glass_df.xlsx")


# In[245]:


df


# In[246]:


#DATA CLEANING
df.head()


# In[247]:


df.tail()


# In[248]:


df.info()


# In[249]:


df.describe()


# In[250]:


df.isnull().sum() # no null present


# In[251]:


df.duplicated().sum()# only one duplicate we can drop that , if multiple we can drop


# In[252]:


df.drop_duplicates(inplace=True) #deleted


# In[253]:


df.duplicated().sum()


# In[254]:


df.isna().sum()


# In[255]:


# EDA segegrate col using dtype 
coln=df.select_dtypes(include="number").columns
cols=df.select_dtypes(exclude="number").columns
coln


# In[256]:


sns.countplot(x="glass_type", data=df) # to check how many variable we have 


# In[257]:


# check outliers with every columns some of the columns overlapping we cant directly drop that feature so will check on emore time with heatmap
for i in coln:
    sns.boxplot(x=df["glass_type"], y=i, data=df)
    plt.title(i)
    plt.show()


# In[258]:


#heatmap
df.corr()
sns.heatmap(df.corr(), annot=True,annot_kws={"size":7})
#'mg', 'al', 'ba', 'na' only this variable has good corr , except this delete all


# In[259]:


df.drop(df[["ri","na","si","k","ca","fe"]], inplace=True, axis=1)


# In[260]:


df["glass_type"].value_counts


# In[173]:


#Delete na with ffil
df["glass_type"]=df["glass_type"].ffill()


# In[242]:


df.isna().sum()


# In[261]:


# Now target varibale has 6 varible will convert into binary
df["glass_type"]=df["glass_type"].map({1:0,2:0,3:0,4:1,5:1,6:1,7:1})


# In[262]:


df["glass_type"].isna().sum()


# In[178]:





# In[263]:


df.isna().sum()


# In[264]:


for column in df.columns:# al and ba has outliers
    
    sns.boxplot(y=df[column],data=df)
    plt.title(f'Box Plot of {column}')
    plt.show()


# In[265]:


#Now model ready to build

x=df.iloc[::,0:3]
y=df.iloc[::,-1:]




# In[267]:


from sklearn.linear_model import  LogisticRegression
from sklearn.model_selection import train_test_split

x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.2, random_state=42)

model=LogisticRegression()
model.fit(x_train, y_train)


# In[268]:


# now validation
y_pred=model.predict(x_test)


# In[270]:


y_pred


# In[271]:


from sklearn.metrics import precision_score, recall_score

precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)

print("Precision:", precision)
print("Recall:", recall)


# In[272]:


from sklearn.metrics import classification_report

print(classification_report(y_test, y_pred))


# In[273]:


#INSIGHTS
For Class 0

Support = 30  There are 30 actual samples of class 0

Precision = 0.90 Out of all predictions made as class 0, 90% were correct

Recall = 0.90 Out of all actual class 0 samples, 90% were correctly identified

F1-score = 0.90 Very good balance between precision and recall

Model performs very well on class 0


# In[274]:


For Class 1

Support = 13  There are 13 actual samples of class 1

Precision = 0.77 Out of all predictions made as class 1, 77% were correct

Recall = 0.77 Out of all actual class 1 samples, 77% were correctly identified

F1-score = 0.77 Moderate performance compared to class 0

Model struggles more with class 1 due to fewer samples


# In[ ]:


Accuracy = 0.86 (86%)

Out of 43 total test samples, 86% were correctly classified

