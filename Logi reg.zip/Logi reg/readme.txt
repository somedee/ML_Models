 Problem Statement

The objective of this project is to identify the type of glass based on its chemical composition and physical properties.
Each glass sample is characterized by features such as refractive index and the percentage of various chemical elements (Sodium, Magnesium, Aluminum, Silicon, Potassium, Calcium, Barium, and Iron).

Using these attributes, the task is to build a machine learning classification model that can accurately predict the glass type of an unknown sample.

This problem is a multiclass classification problem, where the target variable glass_type represents different categories of glass such as building windows, tableware, containers, and headlamps.

 Goal

Analyze the relationship between chemical composition and glass type

Train and evaluate classification models to predict glass type

Measure performance using metrics such as accuracy, precision, recall, and F1-score

Input Variables

Refractive Index (ri)

Sodium (na)

Magnesium (mg)

Aluminum (al)

Silicon (si)

Potassium (k)

Calcium (ca)

Barium (ba)

Iron (fe)

 Target Variable

glass_type – categorical variable representing the type of glass