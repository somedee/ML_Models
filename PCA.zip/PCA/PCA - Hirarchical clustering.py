#!/usr/bin/env python
# coding: utf-8

# In[2]:


# Hirarchical clustering with pca

import numpy as np


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


df=pd.read_csv("D:/DATA SCIENCE PROJECT/Hirarchical clustering/Cricket.csv",encoding='latin1')


# In[4]:


df


# In[5]:


df.head()


# In[6]:


df.tail()


# In[7]:


df.describe()


# In[8]:


df.info() # HS is numerical but in data it is showing object so convert the data type


# In[9]:


df["HS"]=pd.to_numeric(df["HS"], errors="coerce")


# In[10]:


df.info()


# In[11]:


df.shape # as we have 41 null value we will replaace it with mean/ median


# In[12]:


df["HS"].hist()
 # it is left skewed we will replace na value with median


# In[13]:


median=df["HS"].median()


# In[14]:


median


# In[15]:


df["HS"].fillna(median, inplace=True)


# In[16]:


df["HS"].isna().sum()# no null


# In[17]:


df.isna().sum() # no na


# In[18]:


df.isnull().sum()# no null


# In[19]:


df.duplicated().sum()# no duplicates


# In[20]:


df["Span"]# this columns data is not in proper format we will convert into proper format like years of exp/service


# In[21]:


df[["start","end"]]=df["Span"].str.split("-",expand=True) #table expanded and new columns 


# In[22]:


df["start"].dtype # no attribute


# In[23]:


df["start"]=pd.to_numeric(df["start"])# convert no attribute to numeric


# In[24]:


df["end"]=pd.to_numeric(df["end"])


# In[25]:


df["years"]=df["end"]-df["start"]


# In[26]:


df.drop(["Span","start","end"], axis=1, inplace=True) # drop not use ful column


# In[27]:


# check outliers
col=df.iloc[::,1::]


# In[28]:


for i in col.columns:
       sns.boxplot(col[i])
       plt.show()


# In[29]:


# we will check with IQR method also
for j in col.select_dtypes(include='number').columns:

    Q1 = df[j].quantile(0.25)
    Q3 = df[j].quantile(0.75)
    IQR = Q3 - Q1

    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    mask = (df[j] < lower) | (df[j] > upper)

    outliers = df[mask]

    print("Column:", j)
    print("Outliers:", outliers.shape[0])
    print("--------------------")
# mat , inns, runs,hs,ave,bf, sr, 100,50 ,0 have outliers


# In[30]:


# we will check distribution of all columns and then replace outluers with
for i in col.columns:
    sns.histplot(df[i])
    plt.title(i)
    plt.show() # mostly all features are skewed so will use median for replacement


# In[31]:


for s in df.select_dtypes(include='number').columns:

    before = df[s].copy()

    Q1 = df[s].quantile(0.25)
    Q3 = df[s].quantile(0.75)
    IQR = Q3 - Q1

    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    median = df[s].median()

    df.loc[df[s] > upper, s] = median
    df.loc[df[s] < lower, s] = median

    print(s, "→ replaced:", (before != df[s]).sum())


# In[ ]:





# In[32]:


col=df
col.iloc[::,1::]


# In[33]:


# check correlation
df.drop("Player",axis=1,inplace=True)


# In[34]:


sns.heatmap(df.corr(),annot=True,annot_kws={"size": 7})


# In[35]:


df['HS'].describe()   
df.drop("HS",axis=1,inplace=True)


# In[36]:


#standardization
from sklearn.preprocessing import StandardScaler
scaler=StandardScaler()
df=scaler.fit_transform(df)


# In[37]:


df1=pd.DataFrame(df,columns=col.columns)


# In[38]:


df1


# In[39]:


from sklearn.decomposition import PCA

pca = PCA(n_components=0.95)   # out of 100% data keep 95% variance means data
X_pca = pca.fit_transform(df1)


# In[40]:


from scipy.cluster.hierarchy import dendrogram,linkage
linkage_matrix = linkage(df1, method='complete', metric='euclidean')

plt.figure(figsize=(10, 6))
dendrogram(linkage_matrix)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Samples")
plt.ylabel("Euclidean Distance")
plt.show()
plt.show()
#In our dendrogram, there is a big jump around distance 6–7, so around 5 clusters could be a reasonable choice.


# In[41]:


#Validation
from scipy.cluster.hierarchy import fcluster
num_clusters = 6
clusters = fcluster(linkage_matrix, num_clusters, criterion='maxclust')



# In[42]:


df1['Cluster'] = clusters
print(df1['Cluster'].value_counts())



# In[43]:


from sklearn.metrics import silhouette_score

sil_score = silhouette_score(df1, clusters)
print("Silhouette Score:", sil_score) # sil score increases from 19-20


# In[ ]:


# conclusion 
#The Silhouette Score measures how well clusters are separated and how cohesive they are. Its values range from -1 to 1 and our score is 0.20 which is very low means cluster may be overlapping with each other

