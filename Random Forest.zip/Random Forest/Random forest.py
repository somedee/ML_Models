#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


df=pd.read_csv("D:/DATA SCIENCE PROJECT/Random Forest/customer_churn.csv")


# In[4]:


df


# In[5]:


df.head()


# In[6]:


df.describe()


# In[7]:


df.info() # we have cat data and TotalCharges this column has numerical value but datatype as object , so convert object to num


# In[9]:


df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")# coerce means " "" values becomes null also raise, ignore


# In[10]:


df.info()


# In[11]:


df.isna().sum() # there are some na , we are dropping that na


# In[12]:


df=df.dropna()


# In[14]:


df.isna().sum()# dropped


# In[17]:


# feature engg means cehcking which columns is highly related to target column by chi sq
#p < 0.05 → Strong relationship
#p ≥ 0.05 → No significant relationship

from scipy.stats import chi2_contingency

target = "Churn"  

cat_cols = df.select_dtypes(include='object').columns

results = []

for i in cat_cols:
    if i != target:
        table = pd.crosstab(df[i], df[target])

        chi2, p, dof, exp = chi2_contingency(table)

        results.append([i, chi2, p])

chi_df = pd.DataFrame(results, columns=["Feature", "Chi2", "p_value"])

print(chi_df.sort_values("p_value"))


# In[19]:


# As phone service, gender , customerID have p value>=0.05 we can drop them
df=df.drop(df[["customerID","gender","PhoneService"]], axis=1)


# In[20]:


df


# In[23]:


df.duplicated().sum()


# In[22]:


df = df.drop_duplicates()


# In[24]:


# check outliers for numerical column dont have outliers
for col in ["MonthlyCharges", "TotalCharges"]:
    sns.boxplot(df[col])
    plt.title(col)
    plt.show()


# In[25]:


for col in ["MonthlyCharges","TotalCharges"]:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1

    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    out = df[(df[col] < lower) | (df[col] > upper)]
    print(col, "outliers:", out.shape[0])   # no outliers


# In[26]:


# now we will convert cat column value in numerical value using one hot encoding

df=pd.get_dummies(df,drop_first=True)# removed one dummy coulmn



# In[27]:


df


# In[29]:


df = df.astype(int)


# In[30]:


df


# In[34]:


sns.scatterplot(x="tenure",y="MonthlyCharges", hue="Churn_Yes", data=df)
plt.show()#no relationship


# In[35]:


sns.scatterplot(x="tenure",y="TotalCharges", hue="Churn_Yes", data=df)
plt.show()# linear relationship


# In[36]:


# BUild model
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report


# In[39]:


x=df.drop("Churn_Yes",axis=1)
y=df["Churn_Yes"]

x_train,x_test, y_train,y_test=train_test_split(x,y,test_size=0.2)


# In[40]:


model=RandomForestClassifier(n_estimators=100,max_depth=None,random_state=100)    
  
model.fit(x_train,y_train)


# In[41]:


pred=model.predict(x_test)


# In[42]:


from sklearn.metrics import classification_report

print(classification_report(y_test, pred)) #Accuracy seems okay (78%), but the model is not good at detecting churn.


# In[50]:


#We will add parameters to improve accuracy
model2 = RandomForestClassifier(
    n_estimators=300,
    max_depth=12,
    class_weight='balanced',   # improves recall for minority class
    random_state=42,
    n_jobs=-1            
)
model2.fit(x_train,y_train)


# In[51]:


pred2=model2.predict(x_test)


# In[52]:


print(classification_report(y_test,pred2)) # If goal is accuracy only, your current model is fine (~79%).


# In[ ]:


#Conclusion
#The Random Forest model achieved an overall accuracy of 79%, indicating it predicts the majority of customers correctly.

#For non-churn customers (class 0), the model performs very well with high precision (0.83) and recall (0.90).

#For churn customers (class 1), the model shows moderate precision (0.65) but lower recall (0.49), meaning it misses almost half of the customers likely to churn.

