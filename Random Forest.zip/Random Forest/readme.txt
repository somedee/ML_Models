problem

Customer churn is a critical challenge for telecom companies, as acquiring new customers is significantly more expensive than retaining existing ones. The objective of this project is to build a predictive model to identify customers who are likely to churn based on their demographic details, service usage, contract type, and billing information.

The dataset contains customer attributes such as gender, tenure, internet service, contract type, payment method, monthly charges, and total charges, with Churn as the target variable. The goal is to classify customers into churn and non-churn categories while maintaining a balance between precision and recall to minimize the loss of valuable customers.

This model will help the organization take proactive retention strategies, improve customer satisfaction, and reduce revenue loss by identifying high-risk customers in advance.