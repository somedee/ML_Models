#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


df=pd.read_csv("D:/DATA SCIENCE PROJECT/covid_19/covid_19.csv",parse_dates=["Date"]) 


# In[4]:


df


# In[5]:


df.info() #   Date            49068 non-null  object Convert date object to datetime data type


# In[6]:


df.rename(columns={"Country/Region":"Country"})


# In[7]:


df # active cases=confirmed-death-recovered


# In[8]:


df.tail()


# In[9]:


df.drop(["Province/State","Lat","Long","WHO Region"], inplace=True, axis=1)


# In[10]:


df.rename(columns={"Country/Region":"Country"}, inplace= True)


# In[11]:


df.info() # data type is correct


# In[12]:


df.isna().sum() # no na 


# In[13]:


df.isnull().sum() # no null


# In[14]:


df.duplicated().sum() # 1896 records are duplicated 


# In[15]:


df[df.duplicated(subset=['Date','Country'])].head()# some of them are duplicate with zero value


# In[16]:


df.shape  # as we have 49068 records and duplicates are 1896 so can delete it , alos that duplcates have 0 value 1896/49068 *100 we are dropping only 3 percent





# In[17]:


df=df.drop_duplicates()


# In[18]:


df.shape # duplicate dropped


# In[19]:


# check outlier
for i in df.select_dtypes(include="number").columns:
    sns.boxplot(df[i])
    plt.title(i)
    plt.show()


# In[20]:


for col in df.select_dtypes(include="number").columns:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1

    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    df[col] = df[col].clip(lower, upper)


# In[21]:


df[col]


# In[22]:


#A choropleth map is a type of visualization where geographic regions (countries, states, districts) are colored based on a numeric value such as: COVID active cases population literacy rate sales by region
import plotly.express as px


# In[23]:


fig = px.choropleth(
    df,
    locations="Country",
    locationmode="country names",
    color="Active",
    hover_name="Country",
    title="Active COVID Cases by Country",
    
)

fig.show()


# In[23]:


df



# In[32]:


plt.figure(figsize=(20,7))
country_data = df.groupby('Country')['Active'].sum().reset_index()
top20 = country_data.sort_values(by='Active', ascending=False).head(20)
sns.barplot(x='Country', y='Active', data=top20)

plt.show() # high no of active cases in canada


# In[33]:


plt.figure(figsize=(20,7))
country_data = df.groupby('Country')['Confirmed'].sum().reset_index()
top20 = country_data.sort_values(by='Confirmed', ascending=False).head(20)
sns.barplot(x='Country', y='Confirmed', data=top20)

plt.show()


# In[34]:


plt.figure(figsize=(20,7))
country_data = df.groupby('Country')['Deaths'].sum().reset_index()
top20 = country_data.sort_values(by='Deaths', ascending=False).head(20)
sns.barplot(x='Country', y='Deaths', data=top20)

plt.show()


# In[35]:


plt.figure(figsize=(20,7))
country_data = df.groupby('Country')['Recovered'].sum().reset_index()
top20 = country_data.sort_values(by='Recovered', ascending=False).head(20)
sns.barplot(x='Country', y='Recovered', data=top20)

plt.show()


# In[37]:


# FB prophet
get_ipython().system(' pip install prophet')


# In[39]:


from prophet import Prophet


# In[40]:


df


# In[41]:


country_name = "India"

df_c = df[df['Country'] == country_name].copy() #We select data only for ONE country ,Because Prophet works on one time series at a time


df_prophet = df_c[['Date','Active']].rename(columns={  #Prophet compulsory column names
    'Date':'ds',
    'Active':'y'
})

df_prophet['ds'] = pd.to_datetime(df_prophet['ds'])#Prophet needs proper datetime format


# In[45]:


model = Prophet()
model.fit(df_prophet)


# In[46]:


future = model.make_future_dataframe(periods=30) #Take existing dates Add 30 more future days If last date = 2025-21-01 New dates up to = 2026-21-02
forecast = model.predict(future)


# In[47]:


fig = model.plot(forecast) # black dots → actual data, blue line → predicted ,shaded → confidence

plt.title(f"Active Cases Forecast – {country_name}")
plt.xlabel("Date")
plt.ylabel("Active Cases")

plt.show()


# In[ ]:


#Conclusion
1. Trend Understanding

Active cases were low at beginning
Then a sharp exponential rise in middle period
Government can plan hospital beds
Estimate medical resources
Prepare for next wave

