The dataset contains COVID-19 time-series information recorded for different countries on a daily basis. Each row represents the pandemic status for a particular country on a specific date. The data helps to understand how the disease spread, how many people recovered, and how many lost their lives over time.

Important Columns

Date

Represents the calendar date of the record.

It is the time index used for trend and forecasting analysis.

Country

Name of the country to which the data belongs.

Used to filter data for country-wise analysis.

Confirmed

Total number of COVID-19 cases confirmed till that date.

Shows overall spread of infection.

Active

Number of patients currently infected on that date.

This is the main target variable for time-series prediction.

Recovered

Number of people who recovered from COVID-19.

Indicates improvement and healthcare effectiveness.

Deaths

Total deaths due to COVID-19.

Measures severity of the pandemic.

Purpose of the Dataset

To analyze the trend of COVID cases over time

To compare active, recovered, and death rates

To build time-series forecasting models (like Facebook Prophet / ARIMA) to predict future active cases

Overall Summary

This dataset provides a structured historical record of the pandemic progression. Using these variables, we can study:

Growth or decline of active cases

Impact of recoveries and deaths

Future case prediction for planning healthcare resources